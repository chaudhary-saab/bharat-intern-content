<?php
$conn = mysqli_connect("localhost","root","","latest" ) or die ("error" . mysqli_error($conn));
?>